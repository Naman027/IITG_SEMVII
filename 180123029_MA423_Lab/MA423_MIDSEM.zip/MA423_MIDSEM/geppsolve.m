function x = geppsolve(A, b)
%This function is called as x = geppsolve(A,b) 
%which gives solution to system of equations(Ax=b) where A is square matrix
%and b is a vector
    [L, U, p] = gepp(A);
    y = rowforward (L, b(p,:));
    x = colbackward (U, y);
end
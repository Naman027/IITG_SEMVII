function b = colbackward(U,b)
%This function is called as x = colbackward(U,b) 
%It evaluates solution of Upper Triangular System of Equations(Ux = b) 
% using Column Oriented Backward Substitution where
%U is n*n upper triangular matix and b is n*1 vector
    n = size(b,1);
    for j=n:-1:1
        if U(j,j) ~= 0
            b(j) = b(j)/U(j,j);  
        else
            error('Matrix is singular');
        end
        for i=j-1:-1:1
            b(i) = b(i)-U(i,j)*b(j);
        end
    end    
end
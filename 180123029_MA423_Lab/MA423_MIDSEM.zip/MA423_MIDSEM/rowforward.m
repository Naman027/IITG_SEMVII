function b = rowforward(L,b) 
%This function is called as x = rowforward(L,b) 
%It evaluates solution of Lower Triangular System of Equations(Lx = b) 
% using Row Oriented Forward Substitution where
%L is n*n lower triangular matix and b is n*1 vector
    n = size(b,1);
    for k=1:n
        for j=1:k-1
            b(k) = b(k)-L(k,j)*b(j);
        end
        if L(k,k) ~= 0
            b(k) = b(k)/L(k,k);
        else
            error('Matrix is singular');
        end
    end     
end
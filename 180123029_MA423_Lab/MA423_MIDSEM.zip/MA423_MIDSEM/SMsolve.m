function [x] = SMsolve(A, u, v, m, b)
    inv = inverse(A);
    den = 1-(v'*inv*u);
    neu = (inv*u)*v'*inv;
    s = inv + neu/den;
    x = (s^m)*b;
end
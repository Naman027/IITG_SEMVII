function [inv] = inverse(A)
    n = size(A,1);
    I = eye(n);
    for i=1:n
        res = geppsolve(A,I(:,i));
        inv(:,i) = res;
    end
    inv
end
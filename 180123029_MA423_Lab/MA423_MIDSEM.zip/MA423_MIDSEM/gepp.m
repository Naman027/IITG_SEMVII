function [L, U, p] = gepp(A)
%This function is called as [L,U,p]= gepp(A) 
%It evaluates LU decomposition of permutation of square matrix(P*A = L*) using GEPP 
%where A is n*n matrix
    n = size(A,1);
    p = (1:n)';
    for k = 1:n-1
        [~,m] = max(abs(A(k:n,k))); %Finding the maximum value index in ith column row start from ith index to end
        m = m+k-1; %updating maximum value index such that maximum value index of the submatrix + shift
        if(k ~= m)
             A([k m],:) = A([m k],:);  
             p([k m]) = p([m k]);
        end     
        if A(k,k) ~= 0
            A(k+1:n,k) = A(k+1:n,k)/A(k,k);
        else
            continue;
        end
        A(k+1:n,k+1:n) = A(k+1:n,k+1:n) - A(k+1:n,k)*A(k,k+1:n);
    end
    L = eye(n)+tril(A,-1);
    U = triu(A);
end



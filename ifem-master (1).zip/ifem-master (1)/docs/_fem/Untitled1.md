```matlab
node = [1,0,0; 0,1,0; 0,0,0; 0,0,1];
elem = [1 2 3 4];
localEdge = [1 2; 1 3; 1 4; 2 3; 2 4; 3 4];
```


```matlab
figure;
showmesh3(node,elem);
```

    [0;31mError using eval
    Undefined function 'showmesh3' for input arguments of type 'double'.
    
    [0m


    
![png](Untitled1_files/Untitled1_1_1.png)
    



```matlab

```

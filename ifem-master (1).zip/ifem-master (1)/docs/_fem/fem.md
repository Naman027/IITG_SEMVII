---
permalink: /fem/
title: "Finite Element Methods"
sidebar:
    nav: fem
---


- [Finite Element Methods for Poisson Equation]({{ site.baseurl }}{% link _fem/Poisson.md %})
- [Projects: Linear Finite Element Methods]({{ site.baseurl }}{% link _projects/projectFEM.md %})
- [List of Examples]({{ site.baseurl }}{% link _fem/examples.md %})
- [Work Flow]()

# Quadratic Element for Non-Divergence Form Elliptic Equation

## Basis and DoF

The weak function space consists of three parts $\{u_0, u_b, u_g\}$. Here we use continuous P2 element and chose $u_b$ as the trace of $u_0$


```matlab
 e $u_b$ as the trace of $u_0$. So only two components $\{u_0, u_g\}$. 

why?
```




    5




```matlab

```

---
permalink: /research/template/
title: "Template page for community research"
excerpt: "testing community hub"
author: Long Chen # replace this with your name and add to _data/authors.yml
sidebar:
    nav: research
---

## Introduction

$$
E = mc^2
\tag{1}\label{eq:1}
$$

`\eqref{}` can be used to refer to equations. For example the equation \eqref{eq:1} is the rendering of 
```latex
$$
E = mc^2
\tag{1}\label{eq:1}
$$
```


## Codes

```matlab
% enlighten readers what are the key modifications to the codebase?
a = 1;
b = [1,2,3];
```

## Reference

```bibtex
@misc{bibkey,
    title={Your research},
    author={Your Name and Your Collaborators},
    year={20xx},
    publisher={Some publisher}
}
```
```
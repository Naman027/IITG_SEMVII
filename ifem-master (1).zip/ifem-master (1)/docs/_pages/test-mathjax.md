---
permalink: /test/weak-formulation/
title: "Weak formulation"
excerpt: "FEM 101"
sidebar:
    nav: fem
---

## This is a test page

$$
(a\nabla u, \nabla v) = \langle f, v\rangle
$$
---
permalink: /mesh/dof3edge/
title: "Dof on Edges in Three Dimensions"
sidebar:
    nav: mesh
---

